# Name, Student Number
# Oluwatomilayo Adegbite, 500569283
# Nikolas Maier, 500461990

In order to run our program please just run run.py.

It will ask which algorithm you wish to use, and request if you want to change any of the inputs (p1, p2, alpha, gamma, epsilon, episode length, iterations, maximum steps for the agent to take).

Output is average length of episode, time the last iteration took to run, number of succesful runs and finally the policy for each quadrant of the Grid World as shown by arrows.

The reason for making each grid its own seperate quadrant is that we can now control all the door connections and dimensions of the GridWorld components, theoretically allowing the user to eventually create mazes and other such things out of the objects.